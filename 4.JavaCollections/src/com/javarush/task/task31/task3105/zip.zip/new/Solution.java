package com.javarush.task.task31.task3105;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javafx.util.Pair;

/* 
Добавление файла в архив
*/

public class Solution {

    public static void main(String[] args) throws IOException {
        args = new String[]{
                "/home/sb_work/Загрузки/JavaRushTasks/4.JavaCollections/src/com/javarush/task/task31/task3105/Solution.java",
                "/home/sb_work/Загрузки/JavaRushTasks/4.JavaCollections/src/com/javarush/task/task31/task3105/zip.zip"
        };

        final Path fileName = Paths.get(args[0]);
        final Path archive = Paths.get(args[1]);

        List<Pair<ZipEntry, byte[]>> zipEntries;
        try (final ZipInputStream inputStream = new ZipInputStream(
                new BufferedInputStream(Files.newInputStream(archive)))) {
            zipEntries = zipEntries(inputStream);
        }

        try (final BufferedInputStream bufferedInputStream = new BufferedInputStream(
                Files.newInputStream(fileName))) {
            final String newFileName = Paths.get("new/")
                    .resolve(fileName.getFileName())
                    .toString();
            final ZipEntry entry = new ZipEntry(newFileName);

            System.out.println(newFileName);

            zipEntries.removeIf(pair ->  newFileName.equals(pair.getKey().getName()));
            zipEntries.add(new Pair<>(entry, content(bufferedInputStream)));
        }



        try (final ZipOutputStream outputStream = new ZipOutputStream(
                Files.newOutputStream(archive))) {
            for (Pair<ZipEntry, byte[]> zipEntry : zipEntries) {
                final ZipEntry entry = new ZipEntry(zipEntry.getKey());
                final byte[] buffer = zipEntry.getValue();

                outputStream.putNextEntry(entry);
                if (!entry.isDirectory()) {
                    outputStream.write(buffer);
                }
            }
        }
    }

    private static byte[] content(BufferedInputStream bufferedInputStream) throws IOException {
        final byte[] buffer = new byte[bufferedInputStream.available()];

        bufferedInputStream.read(buffer);
        return buffer;
    }

    private static List<Pair<ZipEntry, byte[]>> zipEntries(ZipInputStream inputStream) {
        final List<Pair<ZipEntry, byte[]>> entries = new LinkedList<>();

        try {
            ZipEntry entry = inputStream.getNextEntry();

            while (entry != null) {
                final byte[] buffer = copy(inputStream);

                entries.add(new Pair<>(entry, entry.isDirectory() ? null : buffer));
                entry = inputStream.getNextEntry();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return entries;
    }

    private static byte[] copy(ZipInputStream inputStream)
            throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        int value = inputStream.read();

        while (value != -1) {
            out.write(value);
            value = inputStream.read();
        }
        return out.toByteArray();
    }
}
